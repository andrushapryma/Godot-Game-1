# Instalation

Copy the folder _addons_ into your project than activate the plugin at Project > Project Settings > Plugins > Sprite Trail (Status:) set as _Active_.

# Usage

A new node will be available called SpriteTrail. Create it as a child of a Sprite or an AnimatedSprite. Set _Active_ as true on the inspector and you'll see the trail if you move the Sprite/AnimatedSprite. Change the settings at the inspector as you want.

There is an Example.tscn scene in this repository with an implementation.
