using Godot;
using System;

public class Main : Node2D
{
    // Declare member variables here. Examples:
    // private int a = 2;
    // private string b = "text";

    // Called when the node enters the scene tree for the first time.
    public override void _Ready()
    {
        GetNode<Character>("Player1")._joystick = GetNode("Joystick1").GetChild<Joystick>(0);
        GetNode<Character>("Player2")._joystick = GetNode("Joystick2").GetChild<Joystick>(0);
        GetNode<Character>("Player1")._joystick.i =GetNode<Character>("Player1").i;
        GetNode<Character>("Player2")._joystick.i = GetNode<Character>("Player2").i;
    }

//  // Called every frame. 'delta' is the elapsed time since the previous frame.
//  public override void _Process(float delta)
//  {
//      
//  }
}
