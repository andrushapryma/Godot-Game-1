using Godot;
using System;

public class Ammo : RigidBody2D
{
    // Declare member variables here. Examples:
    // private int a = 2;
    // private string b = "text";

    // Called when the node enters the scene tree for the first time.
    public override void _Ready()
    {
        
    }
    private void _on_Area2D_body_entered(Node2D b)
    {
            GD.Print(b.Name);

        if(b.Name.Contains("Player"))
        {
            
            if( b.GetNode("right_hand").GetChild<Weapon>(0)._currentAmmo < b.GetNode("right_hand").GetChild<Weapon>(0)._maxAmmo  )
           { b.GetNode("right_hand").GetChild<Weapon>(0)._currentAmmo += 5;
           var p = GD.Load<PackedScene>("res://boxes/splash.tscn").Instance<Particles2D>();
           GetParent().AddChild(p);
           p.GlobalPosition = GlobalPosition;
           p.Emitting = true;
           }
             if( b.GetNode("right_hand").GetChild<Weapon>(0)._currentAmmo > b.GetNode("right_hand").GetChild<Weapon>(0)._maxAmmo  )
             b.GetNode("right_hand").GetChild<Weapon>(0)._currentAmmo = b.GetNode("right_hand").GetChild<Weapon>(0)._maxAmmo;
            b.GetNode("infos").GetNode<Sprite>("ammo").Scale = new Vector2(b.GetNode("right_hand").GetChild<Weapon>(0)._currentAmmo*0.1f,b.GetNode("infos").GetNode<Sprite>("ammo").Scale.y);
            QueueFree();
            if(b.GetNode("infos").GetNode<Sprite>("ammo").Scale.x >1)
            {
                b.GetNode("infos").GetNode<Sprite>("ammo").Scale = new Vector2(1,1);
            }
        }
    }

//  // Called every frame. 'delta' is the elapsed time since the previous frame.
//  public override void _Process(float delta)
//  {
//      
//  }
}
