using Godot;
using System;

public class Bullet : KinematicBody2D
{
 
    const float speed = 375;
    public Vector2 direction = Vector2.Right;
    [Export] PackedScene smokeScene;
    [Export] PackedScene bulletImpact;
    public int i;
    public int damage;
    bool exp = false;

public override void _Process(float delta)
{
	var CollisonResult = MoveAndCollide(direction*speed*delta);
	
	if (CollisonResult != null && exp)
    {   
        var smoke = smokeScene.Instance() as Particles2D;	
		GetParent().AddChild(smoke);
		smoke.GlobalPosition = CollisonResult.Position;
		smoke.Rotation = CollisonResult.Normal.Angle();
		var impact = bulletImpact.Instance() as Node2D;
		GetParent().AddChild(impact);
        impact.GetChild<AnimationPlayer>(0).Play("default");
		impact.GlobalPosition = CollisonResult.Position;
		impact.Rotation = CollisonResult.Normal.Angle();
        QueueFree();
		
    }
}

private void _on_Area2D_area_entered(Area2D a)
{
    GD.Print("Bullet :" + a.Name);
    if(a.Name.Contains("Head") && a.GetParent<Character>().i!=i)
    {
        a.GetParent<Character>().ApplyDamage(3* damage);
    }
    else if(a.Name.Contains("Body") && a.GetParent<Character>().i!=i)
    {
        a.GetParent<Character>().ApplyDamage( damage);
    }
    exp = true;
}
private void _on_Area2D_body_entered(Node2D b)
{
      exp = true;
}
private void _on_Timer_timeout()
{
    GetNode<CollisionShape2D>("CollisionShape2D").Disabled = false;
}

}