using Godot;
using System;
using System.Text.RegularExpressions;
public class Character: KinematicBody2D
{
enum STATE{
	IDLE,
	JUMP,
	WALK,
	NEW_DIRECTION,
	WALL,
	FALL,
	LAND,
	ROLLING,
	DEAD
    }
    public float _speed = 100;
    float _gravity = 10;
    STATE state = STATE.IDLE;
    Vector2 _direction = Vector2.Right;
    AnimatedSprite _sprite;
    Vector2 _velocity = new Vector2(0,0);
    bool _onFloor;
    bool _onWall;
    Area2D _rayCast;
    Sprite _handR;
    Sprite _handL;
	private Vector2 platVel = Vector2.Zero;
    
   
    Node2D _info ;
    bool _canJump;
    public float _jump = 600;
    public Joystick _joystick;
	public float _health = 100;
	[Export]public  int i;

    public override void _Ready()
    {
        _rayCast = GetNode<Area2D>("Area2D");
        _handR = GetNode<Sprite>("right_hand");
        _handL = GetNode<Sprite>("left_hand");
		GetNode<Events>("/root/Events").Connect("SetItem", this , "SetItem");
		_sprite = GetNode<AnimatedSprite>("AnimatedSprite");
		GetNode<AnimationPlayer>("AnimationPlayer").Play("def");
		
		if(i == 1)
		{
		CollisionLayer = 2;
		}
		else {CollisionLayer = 1;
		
		}	;
		
//		GetNode<KinematicBody2D>("Head").CollisionLayer = CollisionLayer;
		 
		

    

    }
	private void SetItem(string _name)
	{
		var b = GD.Load<PackedScene>("res://assets/Weapons/" + _name + ".tscn").Instance<Weapon>() ;
		b.i = i;
		_handR.AddChild(b);
	}






public override void  _Process(float delta)
{
	if (state != STATE.ROLLING)
    {
		UpdateHands();
    }
	//platVel = 
	
	


	GetNode<Label>("Label").Text = state.ToString();
    _velocity = MoveAndSlideWithSnap(_velocity, Vector2.Down, Vector2.Up);
    CheckGround();
    NewDirection(delta);
	ApplyGravity();
	_gravity = 10;
    switch (state)
    {
		
        case STATE.IDLE:
        {
            Idle();
            break;
		}
        case STATE.WALK:
        {
            Walk();
            break;
		}
        case STATE.JUMP:
        {
            Jump();
            break;
        }
        case STATE.WALL:
        {
            Wall(delta);
			
            break;
        }
        case STATE.FALL:
        {
            Fall();
			CorrectLand();
            break;
        }
        case STATE.LAND:
        {
            Land();
            break;
        }
        case STATE.DEAD:
        {
            Die();
            break;
        }
    }

}
private void _on_AnimatedSprite_animation_finished()
{
	if(_sprite.Animation == "jump")
	{
		state = STATE.FALL;
	}
}
	
	
	


private int  NewDirection(float delta)
{
	if(_joystick ==null) return 0;
	
	if (_onWall)
		state = STATE.WALL;
	if (_joystick.direction.x !=0)
		_sprite.FlipH = _joystick.direction.x < 0;
	if  (state != STATE.FALL &&state != STATE.JUMP && state != STATE.WALL )
		_velocity.x = _joystick.direction.x*_speed;
	if (_onFloor && _joystick.direction.y>=-0.6)
		state = STATE.WALK;
	if (_joystick.direction.y <=-0.6 && _onFloor)
		{state = STATE.JUMP;
		}

	if (_joystick.direction == Vector2.Zero)
		if (_onFloor)
        {
			_velocity.x = 0;
			state = STATE.IDLE;
        }

	if (_joystick.direction.y<=-0.6 && _onFloor==true &&  state!=STATE.WALL)
		{_velocity.y = -250;
		_onWall = false;
		_canJump = false;}
		return 0;
	}



private void  CheckGround()
{
	for (var i = 0; i <  GetSlideCount(); i++)
    {
		var collision = GetSlideCollision(i);
	
		if (((Node2D)collision.Collider ).Name.Contains("floor"))
        {
			_handR.FlipH = false;
			_onFloor = true;
			_onWall = false;
			_canJump = true;
			_velocity.y = 0;
			break;
        }

		else  if (collision.Collider.GetType().Name =="wall" ) 
			if (_joystick.direction != Vector2.Zero)
				if (_onFloor == false && _joystick.direction.x!=0){
					_velocity.y=0;
					_canJump = true;
					_onWall = true;
					break;}
				
		else{
			_onFloor = false;
			_canJump = false;
			_onWall = false;
			}
    }
}


private void  Jump(){
	if (_onFloor)
    {
		GetNode<Events>("/root/Events").EmitSignal("ShakeCamera");
		_velocity.y = _jump*_joystick.direction.y;
		_onFloor = false;
		_sprite.Animation = "jump";
		var s = GD.Load<PackedScene>("res://assets/BulletSmoke.tscn").Instance<Node2D>();
		s.GetChild<AnimationPlayer>(0).Play("default");
		GetParent().AddChild(s);
		s.Position = Position + new Vector2(0,15);
    }
	
	 }

private void  Fall()
{
	RotationDegrees  = 0;
	_sprite.Animation = "fall";

}

		



private void  Land()
{
	_onFloor = true;
	if (_joystick.direction.x !=0)
		_sprite.FlipH = _joystick.direction.x < 0.1;
	GetNode<Events>("/root/Events").EmitSignal("ShakeCamera");
}


private void  Idle()
{
	GetNode<AnimationPlayer>("AnimationPlayer").PlaybackSpeed = 1;
    _sprite.Animation = "idle";
	GetNode<Node2D>("AnimatedSprite/Copy").Set("active", false );

}

private void  Walk()
{
	GetNode<AnimationPlayer>("AnimationPlayer").PlaybackSpeed = 3;
    _sprite.Animation = "walk";
	GetNode<Node2D>("AnimatedSprite/Copy").Set("active", false );

}
	
	

private void ApplyGravity()
{
    _velocity.y += _gravity;
}
	

private void  Wall(float delta)
{
	GetNode<Node2D>("AnimatedSprite/Copy").Set("active", true );
	_sprite.FlipH = true;
	_sprite.Animation = "wall";
	bool value = false;
		value = false;
	

	value = GetNode<RayCast2D>("RWallChech").IsColliding();
	int sign = value ? -1 : 1;
	MoveAndSlide(new Vector2(300 * sign ,-600));
	state = STATE.NEW_DIRECTION;


	
	if (_onFloor)
		state = STATE.NEW_DIRECTION;

	if (!_onFloor &&  !_onWall)
		{state = STATE.FALL;
		_canJump = false;}
		state = STATE.FALL;
}



private void platf(Node2D body)
{
	if (body.Name.Contains("platform") && !_onWall)
{	GD.Print("on platf");
	 _velocity.x -=  body.GetParent<Platform>().vel.x ;
}
}

private void  CorrectLand(){
	//_rayCast.Position = new Vector2(_rayCast.Position.x,  54+Math.Abs(Position.y)/10)   ;    
	

}
private void _on_Area2D2_body_entered(Node2D b)
{
	//GD.Print(b.GetParent().Name);
	if(b.GetParent().Name == "body"  )
	{
		
		if(b.GetParent<RigidBody2D>().LinearVelocity.Length()>10)
		{
			//ApplyDamage(10);
		}
	}
	if(b.Name.Contains("wall") )
	{
	GetNode<Events>("/root/Events").EmitSignal("ShakeCamera");

		_onWall = true;
	}
}

private void  UpdateHands()
{
if(_joystick!=null){
    
	if (_joystick.direction != Vector2.Zero)
    {
		_handL.Rotation = _joystick.pos.Angle();
		_handR.Rotation = _joystick.pos.Angle();
	}
}
}
public void Die()
{

	var c = GD.Load("res://particles/dead.tscn") as PackedScene;
	var b = c.Instance<Node2D>();
	b.GetChild<CPUParticles2D>(0).Emitting=true;
	b.GetChild<CPUParticles2D>(1).Emitting=true;
	b.GetChild<CPUParticles2D>(2).Emitting=true;
	b.Position = Position;
	GetParent().AddChild(b);
	Hide();
	QueueFree();
	GetTree().ReloadCurrentScene();
}
public void ApplyDamage(int damage)
{
	_health-= damage;
	GetNode("infos").GetNode<Sprite>("hp").Scale = new Vector2(_health/100,GetNode("infos").GetNode<Sprite>("hp").Scale.y);
	var c = GD.Load("res://particles/hit.tscn") as PackedScene;
	var b = c.Instance<CPUParticles2D>();
	GetNode<Events>("/root/Events").EmitSignal("ShakeCamera");
	AddChild(b);
	b.Emitting=true;
	b.GlobalPosition = GlobalPosition;
	GetNode<AnimationPlayer>("AnimationPlayer").Play("hit");
	if(_health<=0)
	{
		Die();
		GetNode<Events>("/root/Events").EmitSignal("ShakeCamera");
	}
}


}