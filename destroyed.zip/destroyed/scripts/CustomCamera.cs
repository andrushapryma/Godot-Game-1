using Godot;
using System;

public class CustomCamera : Camera2D

{
    bool _can = false;
    
   
    RandomNumberGenerator _rng = new RandomNumberGenerator();
        float _shakeStrength = 0.0f;
    float _randomShakeStrength = 0.1f;
    float _shakeDecayRate = 1f;
    float _noiseShakeSpeed = 6;
    float _noiseShakeStrength = 0.01f;
    OpenSimplexNoise _noise = new OpenSimplexNoise();
    float _noiseI = 0;
    
    public override void _EnterTree()
    {
        GetNode<Events>("/root/Events").Connect("ShakeCamera",this,"Shake");
    }
    private void Shake()
    {
        _can = true;
        ApplyShake();
        GetNode<Timer>("Timer").Start();
        
      //Offset = Vector2.Zero;
    }
    private void _on_Timer_timeout()
    {
        _can = false;
        Offset = new Vector2(0,0);
    }
    public override void _Process(float delta)
    {
        if(_can)
        {
                OffsetH = GetNoiseOffset(delta).x;
        OffsetV = GetNoiseOffset(delta).y;
        }



    }






    private Vector2 GetRandomOffset()
        {
        return new Vector2(
            _rng.RandfRange(-_shakeStrength,-_shakeStrength),
            _rng.RandfRange(-_shakeStrength,-_shakeStrength)
        );
    }
    private Vector2 GetNoiseOffset(float delta)
    {
        _noiseI += delta * _noiseShakeSpeed;
        return new Vector2(
            _noise.GetNoise2d(1,_noiseI ) *_shakeStrength,
            _noise.GetNoise2d(100,_noiseI ) *_shakeStrength
        );

    }
     public void ApplyShake()
    {
        _shakeStrength = _randomShakeStrength;
        
    }
    private void ShakeCamera(float power)

    {
        _randomShakeStrength = power;
        //_noiseShakeStrength = power;
        //_shakeStrength = power;
        ApplyShake();
    }
    private void _on_CameraRoot_tree_exiting()
    {
        _noise.Dispose();
        _rng.Dispose();
    }

    // Declare member variables here. Examples:
    // private int a = 2;
    // private string b = "text";

    // Called when the node enters the scene tree for the first time.
    public override void _Ready()
    {
                _noise.Seed = (int)_rng.Randi();
        _noise.Period = 2;
    }

//  // Called every frame. 'delta' is the elapsed time since the previous frame.
//  public override void _Process(float delta)
//  {
//      
//  }
}
