using Godot;
using System;
using System.Collections.Generic;
using System.Linq;

public class EventManager : Node
{
    [Export] int x1;
    [Export] int x2;
    RandomNumberGenerator _rng;
    public String[] s = {"Box", "Meteor", "Saw"};
    int i;
    
    // Declare member variables here. Examples:
    // private int a = 2;
    // private string b = "text";

    // Called when the node enters the scene tree for the first time.
    public override void _Ready()
    {
        _rng = new RandomNumberGenerator();
    }
    private void _on_Meteor_timeout()
    {

    }
    private void _on_ammo_timeout()
    {
        _rng.Randomize();
        var a = GD.Load<PackedScene>("res://assets/Platform.tscn").Instance<Node2D>();
        AddChild(a);
        a.GlobalPosition = new Vector2(_rng.RandiRange(x1, x2) , 750 - i*50 );
        i+=1;
        if(i>=4)
            GetNode<Timer>("ammo").Stop();
    }
    private void _on_bust_timeout()
    {

    }
    private void _on_event_timeout()
    {
    


        _rng.Randomize();
        var i = _rng.RandiRange(0, 2);
        var a = GD.Load<PackedScene>("res://assets/Events/" + s[i] + ".tscn").Instance<Node2D>();
        AddChild(a);
        
        if(i != 2)
        {
            _rng.Randomize();
            a.GlobalPosition = new Vector2(_rng.RandiRange(x1, x2) , 400);
        }
        else
        {
            _rng.Randomize();
         a.GlobalPosition = new Vector2(_rng.RandiRange(x1, x2) , 700);



        }
    }

//  // Called every frame. 'delta' is the elapsed time since the previous frame.
//  public override void _Process(float delta)
//  {
//      
//  }
}
