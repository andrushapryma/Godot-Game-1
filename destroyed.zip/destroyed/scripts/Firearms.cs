using Godot;
using System;

public abstract class Firearms : Weapon
{
protected PackedScene bullet;
protected Vector2 direction;

public float pos;


protected virtual void Shoot(int index)
{
    if(i == index && _currentAmmo>0)

{
    var f = GD.Load<PackedScene>("res://particles/Fire.tscn").Instance<Particles2D>();
	AddChild(f);
	f.GlobalPosition =GetNode<Position2D>("Muzzle").GlobalPosition;
	f.Emitting = true;
	var bullet_inst = bullet.Instance<Bullet>();
    bullet_inst.i = i;
    bullet_inst.damage = damage;
	direction = GetParent(). GetParent<Character>()._joystick.dir;
	 GetNode<Events>("/root/Events").EmitSignal("ShakeCamera");
	
	bullet_inst.direction = direction;
	bullet_inst.Rotation = pos;
	GetTree().Root.GetNode("Scene").AddChild(bullet_inst);
	bullet_inst.GlobalPosition = GetNode<Position2D>("Muzzle").GlobalPosition;
	bullet_inst.Rotate(direction.Angle());
	_currentAmmo -=1;
	GD.Print(_currentAmmo);
	GetParent(). GetParent<Character>().GetNode("infos").GetNode<Sprite>("ammo").Scale = new Vector2(_currentAmmo*0.1f,GetParent(). GetParent<Character>().GetNode("infos").GetNode<Sprite>("ammo").Scale.y);
}
}

//  // Called every frame. 'delta' is the elapsed time since the previous frame.
//  public override void _Process(float delta)
//  {
//      
//  }
}
