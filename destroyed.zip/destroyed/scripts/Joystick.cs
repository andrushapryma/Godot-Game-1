using Godot;
using System;
using System.Runtime.Remoting.Messaging;


public class Joystick : TouchScreenButton
{
    Vector2 radius = new  Vector2(47,47);
    int boundary = 94;
    int return_accel = 20;
    int ongoing_drag = -1;
    int threshold = 10;
    private Vector2  get_button_pos(){
	return Position + radius;}
    public Vector2 direction;
    public Vector2 dir;
    public Vector2 pos1;
    public Vector2 pos;
    public int i;
    
    
public override void _Process( float delta)
{
    GetParent<Sprite>().Scale = new Vector2( OS.WindowSize.x /5000 , OS.WindowSize.x /5000);
    if (ongoing_drag == -1)
    {
		var pos_difference = new Vector2(0, 0) - radius - Position;
		Position += pos_difference * return_accel * delta;
       
    }

	direction = get_value();

	pos = get_button_pos();
	pos1 = GlobalPosition;
}

    public override void _Input(InputEvent @event)
    {
        if (@event is InputEventScreenDrag touch ) 
        {

           
            
         
                
		        var event_dist_from_centre = (GetCanvasTransform().AffineInverse() * touch.Position - GetParent<Node2D>().GlobalPosition).Length();
		    if (event_dist_from_centre <= boundary * GlobalScale.x || touch.Index == ongoing_drag)
            {
			    GlobalPosition = GetCanvasTransform().AffineInverse() * (touch.Position - radius * GlobalScale);
			    if (get_button_pos().Length()>boundary)
                {
				    Position = get_button_pos().Normalized()*boundary-radius;

                }
			    ongoing_drag = touch.Index;
                dir = get_value();
              

                
            
            }
        }
        if (@event is InputEventScreenTouch touch1 )
        {
            if(touch1.IsPressed() == false && touch1.Index == ongoing_drag )
            {
                ongoing_drag = -1;
                
                
                    
                    GetNode<Events>("/root/Events").EmitSignal("Shoot", i    );
                
            }
        }
    }
        
private Vector2 get_value(){
	if (get_button_pos().Length() > threshold)
        return get_button_pos().Normalized();
    return Vector2.Zero;}
    private void _on_TouchScreenButton_pressed()
    {
        GetNode<Events>("/root/Events").EmitSignal("Shoot", i    );
    }
}

