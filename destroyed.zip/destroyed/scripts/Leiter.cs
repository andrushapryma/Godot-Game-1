    using Godot;
using System;

public class Leiter : RigidBody2D
{
    // Declare member variables here. Examples:
    // private int a = 2;
    // private string b = "text";

    // Called when the node enters the scene tree for the first time.
    public override void _Ready()
    {
        
    }
    private void _on_grtound_body_entered(Node2D body)
    {
        if(body.Name == "floor")
        {
            
            Sleeping = true;
           SetDeferred("mode",ModeEnum.Static);
           
            Rotation =0;    
           
        }

    }
    private void _on_Area2D_area_entered(Node2D body)
    {
        if(body.Name == "Player")
        {
           
            Sleeping = true;
           
        }
    }
    private void activate(Node2D b)
    {
        GetNode<CollisionShape2D>("floor/CollisionShape2D").SetDeferred("disabled",false);

    }
    private void deactivate(Node2D b)
    {
        GetNode<CollisionShape2D>("floor/CollisionShape2D").SetDeferred("disabled",true);
    }

//  // Called every frame. 'delta' is the elapsed time since the previous frame.
//  public override void _Process(float delta)
//  {
//      
//  }
}
