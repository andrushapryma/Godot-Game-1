using Godot;
using System;

public class Meteor : RigidBody2D
{
    [Export] PackedScene smokeScene;
    [Export] PackedScene bulletImpact;
    // Declare member variables here. Examples:
    // private int a = 2;
    // private string b = "text";

    // Called when the node enters the scene tree for the first time.
    public override void _Ready()
    {
        
    }
    private void _on_Area2D_area_entered(Area2D body)
    {
                if(body.Name.Contains("Head") )
        {

            if(body.GetParent().GetType().Name.Contains("Character") )
            {
           
            body.GetParent<Character>().ApplyDamage(30);
            }
        }
        if(body.Name.Contains("Body") )
        {
            if(body.GetParent().GetType().Name.Contains ("Character") )
            {
           
            body.GetParent<Character>().ApplyDamage(10);
            }

        }
        var smoke = smokeScene.Instance() as Particles2D;	
		GetParent().AddChild(smoke);
		smoke.GlobalPosition = GlobalPosition;

		var impact = bulletImpact.Instance() as Node2D;
		GetParent().AddChild(impact);
        impact.GetChild<AnimationPlayer>(0).Play("default");
		impact.GlobalPosition = GlobalPosition;
	    var c = GD.Load("res://particles/hit.tscn") as PackedScene;
	    var b = c.Instance<CPUParticles2D>();
	    AddChild(b);
	    GetNode<Events>("/root/Events").EmitSignal("ShakeCamera");
	    b.Emitting=true;
	    b.GlobalPosition = GlobalPosition;
       
        QueueFree();
    }

//  // Called every frame. 'delta' is the elapsed time since the previous frame.
//  public override void _Process(float delta)
//  {
//      
//  }
}
