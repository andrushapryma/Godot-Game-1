using Godot;
using System;

public class Platform : KinematicBody2D
{
    private Vector2 dir = Vector2.Right;
    public Vector2 vel= new Vector2(0,0);
    // Declare member variables here. Examples:
    // private int a = 2;
    // private string b = "text";

    // Called when the node enters the scene tree for the first time.
    public override void _Ready()
    {
       
    }
    public override void _Process(float delta)
    {
        
     vel = dir * delta * 100; 
     var c = MoveAndCollide(vel);
     if(c!= null)
     {
        dir = -dir;
     }
    }
    private void _on_floor_area_entered(Area2D a)
    {
        if(a.Name.Contains("floor"))
        {
          //  QueueFree();
        }
    }
    private void _on_Area2D_area_entered(Area2D b)
    {
        if(b.Name.Contains("Body"))
        {
           GetNode<CollisionShape2D>("CollisionShape2D").SetDeferred("disabled", true);
        }
    }
    private void _on_Area2D_area_exited(Area b)
    {
        GetNode<CollisionShape2D>("CollisionShape2D").SetDeferred("disabled", false);
    }

//  // Called every frame. 'delta' is the elapsed time since the previous frame.
//  public override void _Process(float delta)
//  {
//      
//  }
}
