using Godot;
using System;

public class Saw : RigidBody2D
{
    // Declare member variables here. Examples:
    // private int a = 2;
    // private string b = "text";

    // Called when the node enters the scene tree for the first time.
    public override void _Ready()
    {
        
    }
        private void _on_Area2D_area_entered( Area2D body)
    {

         // body.GetParent<Character>().ApplyDamage(10);
        if(body.Name.Contains("Head") )
        {

            if(body.GetParent().GetType().Name.Contains("Character") )
            {
           
            body.GetParent<Character>().ApplyDamage(30);
            }
        }
        if(body.Name.Contains("Body") )
        {
            if(body.GetParent().GetType().Name.Contains ("Character") )
            {
           
            body.GetParent<Character>().ApplyDamage(10);
            }

        }

    }

//  // Called every frame. 'delta' is the elapsed time since the previous frame.
//  public override void _Process(float delta)
//  {
//      
//  }
}
