using Godot;
using System;

public class Scene : Node2D
{
    // Declare member variables here. Examples:
    // private int a = 2;
    // private string b = "text";

    // Called when the node enters the scene tree for the first time.
    public override void _Ready()
    {
        GetNode<Character>("Player1")._joystick = GetNode<Node2D>("Joystick1").GetChild<Joystick>(0);
        GetNode<Character>("Player2")._joystick = GetNode<Node2D>("Joystick2").GetChild<Joystick>(0);

        


        GetNode<Node2D>("Player1/Head").Name ="Head1";
        GetNode<Node2D>("Player2/Head").Name ="Head2";
        GetNode<Character>("Player1").i =1;
        GetNode<Character>("Player2").i = 2;
         GetNode<Node2D>("Joystick2").GetChild<Joystick>(0).i = 2;
         GetNode<Node2D>("Joystick1").GetChild<Joystick>(0).i = 1;
       //
    }


//  // Called every frame. 'delta' is the elapsed time since the previous frame.
//  public override void _Process(float delta)
//  {
//      
//  }
}
