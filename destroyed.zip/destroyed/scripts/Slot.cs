using Godot;
using System;

public class Slot : VBoxContainer
{
    // Declare member variables here. Examples:
    // private int a = 2;
    // private string b = "text";

    // Called when the node enters the scene tree for the first time.
    public override void _Ready()
    {
        
    }
    private void _on_Slot_pressed()
    {
        GetNode<Events>("/root/Events").EmitSignal("SetItem", Name);
        GD.Print(Name);
        GetParent().GetParent().GetParent().GetParent<Control>().Hide();
       Engine.TimeScale = 1;
    }


//  // Called every frame. 'delta' is the elapsed time since the previous frame.
//  public override void _Process(float delta)
//  {
//      
//  }
}
