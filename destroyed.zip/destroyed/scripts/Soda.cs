using Godot;
using System;

public class Soda : RigidBody2D
{
    Character c;
    // Declare member variables here. Examples:
    // private int a = 2;
    // private string b = "text";

    // Called when the node enters the scene tree for the first time.
    public override void _Ready()
    {
        
    }
    private void _on_Area2D_body_entered(Node2D body)
    {
        GD.Print(body.Name);
        if(body.Name.Contains("Player"))
        {
            c = (Character) body;
            ((Character)body)._jump *=2;

            GetChild<Node2D>(1).QueueFree();
            GetChild<Node2D>(2).QueueFree();
            
            
            GetNode<Timer>("Timer").Start();
        }
    }
    private void _on_Timer_timeout()
    {
        c._jump /=2;
            QueueFree();
        
    }

//  // Called every frame. 'delta' is the elapsed time since the previous frame.
//  public override void _Process(float delta)
//  {
//      
//  }
}
