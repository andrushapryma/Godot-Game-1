using Godot;
using System;
using System.Collections.Generic;

public class Store : CanvasLayer
{
    PackedScene slot ;
    string name;
    public override void _Ready()
    {
       
        Engine.TimeScale = 0;
        slot = GD.Load<PackedScene>("res://assets/Slot.tscn");
        var list = GetFiles("res://scripts/Weapons/");
        foreach(var s in list)
        {
             var a = slot.Instance();
             a.Name = s;
            GetNode<Control>("Control/MarginContainer/Weapons/HBoxContainer").AddChild(a);
            Type _itemType = Type.GetType(s);
            a.GetChild(0).GetChild<Label>(1).Text = s.BaseName();
            a.GetChild(0).GetChild<TextureRect>(0).Texture = GD.Load<Texture>("res://sprites/Weapons/" + s +".png" );
            
            

        }
    }

  

    public static List<string> GetFiles(string path)

    {
    List<string> files  = new List<string>();
    Godot.Directory dir  = new Godot.Directory();
    dir.Open(path);
    dir.ListDirBegin(true,false);
    
  
    var file = dir.GetNext();
    while ( file!= "" )
    {
        
        files.Add(file.Replace(".cs",""));
        file = dir.GetNext();
    
    }
    dir.ListDirEnd();
    
    return files;    
    }


}
