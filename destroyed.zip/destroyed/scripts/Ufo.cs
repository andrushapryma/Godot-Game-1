using Godot;
using System;

public class Ufo : KinematicBody2D
{
    Vector2 dir = Vector2.Right;
    // Declare member variables here. Examples:
    // private int a = 2;
    // private string b = "text";

    // Called when the node enters the scene tree for the first time.
    public override void _Ready()
    {
        GetNode<AnimationPlayer>("AnimationPlayer").Play("def");

    }
    public override void _Process(float delta)
    {
     var c = MoveAndCollide(dir * delta * 100 );
     if(c!= null)
     {
        dir = -dir;
     }
    }
    private void _on_Area2D_body_entered(Node2D b)
    {
        if(b.Name.Contains("Player"))
        {
            ((Character)b).Die();
        }
    }

    //  // Called every frame. 'delta' is the elapsed time since the previous frame.
    //  public override void _Process(float delta)
    //  {
    //      
    //  }

}
