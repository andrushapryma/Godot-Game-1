using Godot;
using System;

public abstract class Weapon : Node2D
{
	Vector2 direction;
	float pos;
	protected int damage;
public int i;
public int _currentAmmo;
public int _maxAmmo;
	

}
