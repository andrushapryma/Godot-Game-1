using Godot;
using System;

public class Ak47 : Firearms
{

    public Ak47()
    {
        _currentAmmo = 10;
        _maxAmmo = 10;
    }

    
    // Declare member variables here. Examples:
    // private int a = 2;
    // private string b = "text";

    // Called when the node enters the scene tree for the first time.
    public override void _Ready()
    {
        bullet = GD.Load<PackedScene>("res://assets/Bullet.tscn");
        GetNode<Events>("/root/Events").Connect("Shoot",this,"Shoot");
        damage = 10;
    }
    protected override void Shoot(int index )
    {
        base.Shoot(index);
    }

//  // Called every frame. 'delta' is the elapsed time since the previous frame.
//  public override void _Process(float delta)
//  {
//      
//  }
}
