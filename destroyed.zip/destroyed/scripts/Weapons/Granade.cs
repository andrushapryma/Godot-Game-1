using Godot;
using System;

public class Granade : Weapon
{
    bool _move = false;
    Vector2 dir;
    float a = 1.1f;
    // Declare member variables here. Examples:
    // private int a = 2;
    // private string b = "text";

    // Called when the node enters the scene tree for the first time.
    public override void _Ready()
    {
         this.GetNode<Events>("/root/Events").Connect("Shoot",this,"Shoot");
         
        i= GetParent(). GetParent<Character>().i;

    }
    private void Shoot(int i)
    {
        if(i == this.i)
        {
            GD.Print("shoot");
        _move = true;
        dir = GetParent(). GetParent<Character>()._joystick.dir;
        var pos = GlobalPosition;
        SetAsToplevel(true);
        GlobalPosition = pos;
         this.GetNode<Events>("/root/Events").Disconnect("Shoot",this,"Shoot");
         var a = GD.Load<PackedScene>("res://assets/Weapons/Granade.tscn").Instance<Node2D>();
         GetNode<AnimationPlayer>("AnimationPlayer").Play("throw");
         GetParent().AddChild(a);
         a.GlobalPosition = GlobalPosition;
         GetNode<Node2D>("Sprite/Copy").Set("emit", true );
        }

    }
    public override void _Process(float delta)
    {
        if(_move)
        {
         
           
            Position = Position + dir*a ;
            a+=delta;
            //ApplyCentralImpulse(new Vector2(1,1) *1);
        }
    }
    private void _on_Area2D_body_entered(Node2D b)
    {
        GD.Print(b.Name);
        if(_move && !b.Name.Contains("Granade") && !b.Name.Contains("Player" + i)    ){
            SceneTreeTween t1= CreateTween();
             SceneTreeTween t2= CreateTween();
            t1.TweenProperty(GetNode<CollisionShape2D>("Expos/CollisionShape2D"), "scale", new Vector2(10,10), 0.2f);
            t2.TweenProperty(GetNode<Sprite>("Sprite2"), "scale", new Vector2(10,10), 0.2f);
         
            t1.TweenProperty(GetNode<CollisionShape2D>("Expos/CollisionShape2D"), "scale", new Vector2(1,1), 1f);
            t2.TweenProperty(GetNode<Sprite>("Sprite2"), "scale", new Vector2(0,0), 1f);
            t2.TweenCallback(this, "queue_free");
            
           
         //    GetNode<AnimationPlayer>("AnimationPlayer").Stop();
         //   GetNode<AnimationPlayer>("AnimationPlayer").Play("exp");
         //   GD.Print(b.Name);
       _move = false;

        }
       if(b.Name.Contains ("Player"))
       {
        ((Character)b).ApplyDamage(50);
       }
     


    }
    private void _on_Timer_timeout()
    {
       ((CapsuleShape2D)GetNode<CollisionShape2D>("Area2D/CollisionShape2D").Shape).Radius = 100;
    }

    //  // Called every frame. 'delta' is the elapsed time since the previous frame.
    //  public override void _Process(float delta)
    //  {
    //      
    //  }

}
