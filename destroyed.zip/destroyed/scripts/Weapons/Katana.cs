using Godot;
using System;

public class Katana : Weapon
{
    
    // Declare member variables here. Examples:
    // private int a = 2;
    // private string b = "text";

    // Called when the node enters the scene tree for the first time.
    public override void _Ready()
    {
        damage = 10;
    }
    private void _on_Area2D_body_entered(Node a)
    {
        GD.Print(a.Name);
        if(a.Name.Contains("Player"))
        {
            if(((Character)a).i !=i)
            ((Character)a).ApplyDamage(damage);
        }
        if(a.Name.Contains("Head"))
        {
            if(((Character)a.GetParent()).i !=i)
            ((Character)a.GetParent()).ApplyDamage(3*damage);
        }
    }

//  // Called every frame. 'delta' is the elapsed time since the previous frame.
//  public override void _Process(float delta)
//  {
//      
//  }
}
